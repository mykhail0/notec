Obsługa: Przekopiować notec.asm do folderu z testami i odpalic run_tests.sh, on sam sobie wszystko zbuduje
Buduje testy na 10 noteci, powinno wszystko działać
Aby zmienić liczbę noteci trzeba zmienić zmienną N w makefile
Dla N > 10 W-test nie zadziała
